<?php
defined('server') ? null : define("server", "localhost");
defined('user') ? null : define ("user", "root") ;
defined('pass') ? null : define("pass","");
defined('database_name') ? null : define("database_name", "db_dentalclinic") ;
 
// $web_root =  "https://mcguyverja.com/invoice/"; 
$web_root ="http://localhost/dentalclinic/";


define ('web_root' , $web_root); 
?>